namespace SingularityGroup.HotReload.Editor.ProjectGeneration
{
  internal interface IGUIDGenerator
  {
    string ProjectGuid(string name);
  }
}