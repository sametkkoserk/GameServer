namespace SingularityGroup.HotReload.Editor {
    enum ShowOnStartupEnum {
        Always,
        OnNewVersion,
        Never,
    }
}