﻿namespace SingularityGroup.HotReload.Editor {
    internal interface IGUIComponent {
        void OnGUI();
    }
}
