![HotReloadLogo](https://hotreload.net/logo.png?w=256&q=75)

# Hot Reload for Unity

Edit **any C# function** and get immediate updates in your game. Hot Reload works with your existing project, no code changes required.

Install instructions on https://hotreload.net/

![Modify2dJumpingGameDemo](https://hot-reload-assets.s3.amazonaws.com/assets/hotreload_jump_demo.gif)
